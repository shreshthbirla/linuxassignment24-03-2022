/*
#include<pthread.h>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/mman.h>
void*proc(void *param)
{
sleep(2);
return 0;
}
int main()
{
pthread_attr_t attr;
pthread_t ID;
void *stk;
size_t siz;
int err;
size_t my_stksize = 300000;
void * my_stack;
pthread_attr_init(&attr);
pthread_attr_getstacksize(&attr,&siz);
pthread_attr_getstackaddr(&attr,&stk);

printf("default : addr=%08x default size=%d\n"stk,siz);

my_stack = (void*)malloc(my_stksize);

pthread_attr_setstack(&attr,my_stack,my_stksize);

pthread_create(&ID,&attr,proc,NULL);
pthread_attr_getstack(&attr,&stk,&siz);
printf("newly defined stack: addr=%08x and size=%d\n",stk,siz);
sleep(3);
return 0;

}
*/

#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
//#include<sys/main.h>
#include<unistd.h>

void* proc(void* program)
{
sleep(2);
return 0;
}

int main()
{
pthread_attr_t ATTR;
pthread_t Id;
void *stk;
size_t siz;
int err;

size_t my_stksize=300000;
void * my_stacks;

pthread_attr_init(&ATTR);
pthread_attr_getstacksize(&ATTR,&siz);
pthread_attr_getstackaddr(&ATTR,&stk);

printf("Default: addr=%08x default size=%d\n",stk,siz);

my_stacks=(void*)malloc(my_stksize);

pthread_attr_setstack(&ATTR,my_stacks,my_stksize);
pthread_create(&Id,&ATTR,proc,NULL);
pthread_attr_getstack(&ATTR,&stk,&siz);

printf("newly defined stack :Addr=08%x  and size =%d\n",stk,siz);
sleep(3);
return (0);
}
